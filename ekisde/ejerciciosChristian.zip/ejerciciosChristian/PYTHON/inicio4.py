#Matriz = []
#num = 1
#contador = 0
#for fila in range(5):
 #     Matriz.append([])
#for columna in range(10):
     
 #     matriz = []
 #matriz2= []
 #num = 1#

 
 
#matriz = []
#num = 1
#acumulador = 0 
#for i in range(5)3:
#     fila = []
#     for j in range(10):
#         fila.append(num)
#         acumulador+=num
#     matriz.append(fila)
    
#print(acumulador+1)

matriz=[]
suma = []
cont=1

for fila in range (4):
    matriz.append([])
    for columna in range(6):
      matriz[fila].append(cont)
      cont+=1 
print(matriz)

for fila in range (2):
      suma.append([])
      for columna in range(6):
            suma[fila].append()
            
print(suma)
