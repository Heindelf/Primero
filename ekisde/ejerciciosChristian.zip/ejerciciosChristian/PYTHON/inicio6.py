

Bogota = [19,19,17,18,20]
Bucaramanga = [27,26,26,26,27]
Medellin = [27,26,26,27,29]

sumBogota = (sum([19,19,17,18,20]))
sumBucaramanga = sum([27,26,26,26,27])
sumMedellin = sum([27,26,26,27,29])

promedioBogota = sumBogota /5
promedioBucaramanga = sumBucaramanga/5
promedioMedellin = sumMedellin/5
print(f"el promedio de bogota es de : {promedioBogota} y el maximo fue de {max(Bogota)} y el minimo de {min(Bogota)} , el promedio de bucaramanga es de : {promedioBucaramanga} y el maximo fue de {max(Bucaramanga)} y el minimo fue de {min(Bucaramanga)}, el promedio de medellin es de : {promedioMedellin} y el maximo fue de {max(Medellin)} y el minimo fue de {min(Medellin)}")


