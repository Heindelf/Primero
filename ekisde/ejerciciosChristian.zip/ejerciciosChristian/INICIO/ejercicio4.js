var a  = 1 ; var b = 1 ; var  c=1 ;
for (b ; b<=5 ; b++){console.log(a+"."+b+"."+c+"    -    "+a+"."+b+"."+(c+1)+"    -    "+a+"."+b+"."+(c+2)+"    -    "+a+"."+b+"."+(c+3));}