var n = parseInt(prompt("ingrese un numero positivo"))
var i = 1;
while (i < n){
console.log(i);
i=i+2;
}